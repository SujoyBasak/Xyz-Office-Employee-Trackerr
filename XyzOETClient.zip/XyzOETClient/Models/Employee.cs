﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace XyzOETClient.Models
{
    public class Employee
    {
        [Key]
        [Display(Name ="Employee ID")]
        public int empId { get; set; }
        [Display(Name ="Employee Name")]
        public string Name { get; set; }
        [Display(Name = "Department ID")]
        public int deptId { get; set; }
        [Display(Name = "Department Name")]
        public string deptName { get; set; }
        [Display(Name = "Salary")]
        public int salary { get; set; }

        
    }
}
