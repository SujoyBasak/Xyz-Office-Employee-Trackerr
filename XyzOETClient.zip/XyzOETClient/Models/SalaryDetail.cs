﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace XyzOETClient.Models
{
    public class SalaryDetail
    {
        [Key]
        [Display(Name ="Salary ID")]
        public int salaryId { get; set; }
        [Display(Name ="Employee ID")]
        public int empId { get; set; }
        [Display(Name ="Date of payment")]
        public DateTime date { get; set; }
        [Display(Name ="Salary Amount")]
        public int salary { get; set; }
    }
}
