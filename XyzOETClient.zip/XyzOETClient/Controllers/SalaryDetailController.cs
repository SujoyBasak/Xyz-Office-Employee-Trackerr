﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using XyzOETClient.Models;

namespace XyzOETClient.Controllers
{
    public class SalaryDetailController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44302/api");
        HttpClient client;

        public SalaryDetailController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;

        }

        public IActionResult GetDetails()
        {
            List<SalaryDetail> ls = new List<SalaryDetail>();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/SalaryDetail").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                ls = JsonConvert.DeserializeObject<List<SalaryDetail>>(data);
            }
            return View(ls);
        }
        public IActionResult Details(int id)
        {
            SalaryDetail emp = new SalaryDetail();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/SalaryDetail/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<SalaryDetail>(data);
            }

            return View(emp);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(SalaryDetail emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/SalaryDetail/", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("GetDetails");
            }
            return BadRequest();

        }

        public ActionResult Edit(int id)
        {
            SalaryDetail emp = new SalaryDetail();
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/SalaryDetail/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<SalaryDetail>(data);
            }
            return View(emp);
        }
        [HttpPost]
        public ActionResult Edit(SalaryDetail emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/SalaryDetail/" + emp.salaryId, content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }

        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = client.DeleteAsync(client.BaseAddress + "/SalaryDetail/" + id).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }
    }
}