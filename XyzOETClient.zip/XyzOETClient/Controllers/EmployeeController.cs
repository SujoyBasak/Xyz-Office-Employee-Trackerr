﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using XyzOETClient.Models;

namespace XyzOETClient.Controllers
{
    public class EmployeeController : Controller
    {
        Uri baseAddress = new Uri("https://localhost:44302/api");   //Port No.
        HttpClient client;

        public EmployeeController()
        {
            client = new HttpClient();
            client.BaseAddress = baseAddress;

        }
        
        public IActionResult GetDetails() 
        {
            List<Employee> ls = new List<Employee>();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Employee").Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                ls = JsonConvert.DeserializeObject<List<Employee>>(data);
            }
            return View(ls);
        }
        public IActionResult Details(int id) 
        {
            Employee emp = new Employee();

            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Employee/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<Employee>(data);
            }

            return View(emp);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PostAsync(client.BaseAddress + "/Employee/", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("GetDetails");
            }
            return BadRequest();

        }

        public ActionResult Edit(int id)
        {
            Employee emp = new Employee();
            HttpResponseMessage response = client.GetAsync(client.BaseAddress + "/Employee/" + id).Result;
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                emp = JsonConvert.DeserializeObject<Employee>(data);
            }
            return View(emp);
        }
        [HttpPost]
        public ActionResult Edit(Employee emp)
        {
            string data = JsonConvert.SerializeObject(emp);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/json");

            HttpResponseMessage response = client.PutAsync(client.BaseAddress + "/Employee/" + emp.empId, content).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }

        public ActionResult Delete(int id)
        {
            HttpResponseMessage response = client.DeleteAsync(client.BaseAddress + "/Employee/" + id).Result;
            if (response.IsSuccessStatusCode)
                return RedirectToAction("GetDetails");
            return BadRequest();
        }
    }
}