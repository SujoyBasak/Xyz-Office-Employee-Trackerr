﻿using NUnit.Framework;
using Moq;
using XyzOfficeEmployeeTrackerr.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using XyzOfficeEmployeeTrackerr.Controllers;
using XyzOfficeEmployeeTrackerr.Repository;
using Microsoft.AspNetCore.Mvc;

namespace XyzOfficeEmployeeTrackerrTesting
{
    public class SalaryControllerTest
    {
        EmployeeContext db;

        [SetUp]
        public void Setup()
        {
            var emp = new List<SalaryDetail>
            {
                new SalaryDetail{empId=1,salary=1000,salaryId=1},
                new SalaryDetail{empId=2,salary=1000,salaryId=2},
                new SalaryDetail{empId=3,salary=1000,salaryId=3},

            };

            var salData = emp.AsQueryable();
            var mockSet = new Mock<DbSet<SalaryDetail>>();
            mockSet.As<IQueryable<SalaryDetail>>().Setup(m => m.Provider).Returns(salData.Provider);
            mockSet.As<IQueryable<SalaryDetail>>().Setup(m => m.Expression).Returns(salData.Expression);
            mockSet.As<IQueryable<SalaryDetail>>().Setup(m => m.ElementType).Returns(salData.ElementType);
            mockSet.As<IQueryable<SalaryDetail>>().Setup(m => m.GetEnumerator()).Returns(salData.GetEnumerator());

            var mockContext = new Mock<EmployeeContext>();
            mockContext.Setup(c => c.SalaryDetails).Returns(mockSet.Object);
            db = mockContext.Object;

        }



        [Test]
        public void GetDetailsTest()
        {
            var res = new Mock<SalaryRep>(db);
            SalaryDetailController obj = new SalaryDetailController(res.Object);
            var data = obj.Get();
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);

        }

        [Test]
        public void Add_Valid_Detail()
        {
            var res = new Mock<SalaryRep>(db);
            SalaryDetailController obj = new SalaryDetailController(res.Object);
            SalaryDetail emp = new SalaryDetail { empId = 1, salary = 1000, salaryId = 4 };

            var data = obj.Post(emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }





        [Test]
        public void GetDetailTest()
        {
            SalaryRep res = new SalaryRep(db);
            SalaryDetailController obj = new SalaryDetailController(res);
            var data = obj.Get(1);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }

        [Test]
        public void Update_Valid_Detail()
        {
            SalaryRep res = new SalaryRep(db);
            SalaryDetailController obj = new SalaryDetailController(res);

            SalaryDetail emp = new SalaryDetail { empId = 1, salary = 1000, salaryId = 5 };
            var data = obj.Put(1, emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
        [Test]
        public void Delete_Valid_Detail()
        {
            SalaryRep res = new SalaryRep(db);
            SalaryDetailController obj = new SalaryDetailController(res);
            var data = obj.Delete(1);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
    }
}
