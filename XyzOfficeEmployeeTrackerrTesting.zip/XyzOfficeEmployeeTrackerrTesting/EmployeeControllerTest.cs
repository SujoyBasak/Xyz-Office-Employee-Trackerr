using NUnit.Framework;
using Moq;
using XyzOfficeEmployeeTrackerr.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using XyzOfficeEmployeeTrackerr.Controllers;
using XyzOfficeEmployeeTrackerr.Repository;
using Microsoft.AspNetCore.Mvc;

namespace XyzOfficeEmployeeTrackerrTesting
{
    public class EmployeeControllerTest
    {
        EmployeeContext db;
        
        [SetUp]
        public void Setup()
        {
            var emp = new List<Employee>
            {
                new Employee{empId=1,deptId=10,Name="Dummy 1",deptName="DD",salary=3000},
                new Employee{empId=2,deptId=20,Name="Dummy 2",deptName="DD",salary=4000},
                new Employee{empId=3,deptId=30,Name="Dummy 3",deptName="DD",salary=5000}

            };

            var empdata = emp.AsQueryable();
            var mockSet = new Mock<DbSet<Employee>>();
            mockSet.As<IQueryable<Employee>>().Setup(m => m.Provider).Returns(empdata.Provider);
            mockSet.As<IQueryable<Employee>>().Setup(m => m.Expression).Returns(empdata.Expression);
            mockSet.As<IQueryable<Employee>>().Setup(m => m.ElementType).Returns(empdata.ElementType);
            mockSet.As<IQueryable<Employee>>().Setup(m => m.GetEnumerator()).Returns(empdata.GetEnumerator());

            var mockContext = new Mock<EmployeeContext>();
            mockContext.Setup(c => c.Employees).Returns(mockSet.Object);
            db = mockContext.Object;

        }

        

        [Test]
        public void GetDetailsTest()
        {
            var res = new Mock<EmployeeRep>(db);
            EmployeeController obj = new EmployeeController(res.Object);
            var data = obj.Get();
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);

        }

        [Test]
        public void Add_Valid_Detail()
        {
            var res = new Mock<EmployeeRep>(db);
            EmployeeController obj = new EmployeeController(res.Object);
            Employee emp = new Employee { empId = 4, deptId = 30, Name = "Dummy 3", deptName = "DD", salary = 5000 };

            var data = obj.Post(emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }



        

        [Test]
        public void GetDetailTest()
        {
            EmployeeRep res = new EmployeeRep(db);
            EmployeeController obj = new EmployeeController(res);
            var data = obj.Get1(1);
            var okResult = data as ObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }


        
        [Test]
        public void Update_Valid_Detail()
        {       

            Employee emp = new Employee {deptId = 30, Name = "Dummy 3", deptName = "DD", salary = 5000 };
            EmployeeRep res = new EmployeeRep(db);
            EmployeeController obj = new EmployeeController(res);
            var data = obj.Put(1, emp);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
        [Test]
        public void Delete_Valid_Detail()
        {
            EmployeeRep loandata = new EmployeeRep(db);
            EmployeeController obj = new EmployeeController(loandata);
            var data = obj.Delete(1);
            var okResult = data as OkObjectResult;
            Assert.AreEqual(200, okResult.StatusCode);
        }
    }
}